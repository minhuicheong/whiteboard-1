class Graph {
    constructor() {
        this.graph = new Map();
    }

    addNode(node) {
        if (!this.graph.has(node)) {
            this.graph.set(node, []);
        }
    }

    addEdge(fromNode, toNode) {
        if (this.graph.has(fromNode) && this.graph.has(toNode)) {
            this.graph.get(fromNode).push(toNode);
        }
    }

    findConnectedPath(startNode, endNode) {
        const visited = new Set();
        const path = [];

        const dfs = (currentNode) => {
            visited.add(currentNode);
            path.push(currentNode);

            if (currentNode === endNode) {
                return true; // Found a path
            }

            const neighbors = this.graph.get(currentNode) || [];

            for (const neighbor of neighbors) {
                if (!visited.has(neighbor)) {
                    if (dfs(neighbor)) {
                        return true; // Path found
                    }
                }
            }

            path.pop(); // Remove the node from the path if it doesn't lead to the end node
            return false;
        };

        if (dfs(startNode)) {
            return { exists: true, path };
        } else {
            return { exists: false, path: [] };
        }
    }
}

// Example usage:
const graph = new Graph();
graph.addNode('A');
graph.addNode('B');
graph.addNode('C');
graph.addNode('D');
graph.addNode('E');
graph.addNode('F');

graph.addEdge('A', 'B');
graph.addEdge('B', 'D');
graph.addEdge('D', 'C');
graph.addEdge('F', 'B');
graph.addEdge('F', 'E');

const startNode = 'E';
const endNode = 'D';

const result = graph.findConnectedPath(startNode, endNode);
console.log(result); // Output: { exists: true, path: ['E', 'F', 'B', 'D'] }
