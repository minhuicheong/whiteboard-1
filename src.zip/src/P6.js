function findMaxOccurrenceCharacter(str) {
    const cleanedStr = str.replace(/[\s.,!?]/g, '').toLowerCase();
    
    const charCount = {};
    
    // Iterate through the cleaned string using code points
    for (const char of cleanedStr) {
        const codePoint = char.codePointAt(0);
        if (charCount[codePoint]) {
            charCount[codePoint]++;
        } else {
            charCount[codePoint] = 1;
        }
    }
    
    let maxChar = '';
    let maxCount = 0;
    
    // Find the character with the maximum occurrence
    for (const codePoint in charCount) {
        if (charCount[codePoint] > maxCount) {
            maxChar = String.fromCodePoint(Number(codePoint));
            maxCount = charCount[codePoint];
        }
    }
    
    return {
        Character: maxChar,
        Occurrence: maxCount
    };
}

// Example usage:
const inputString = "Hello, world! 你好世界";
const result = findMaxOccurrenceCharacter(inputString);
console.log(result); // Output: { Character: 'l', Occurrence: 3 }
