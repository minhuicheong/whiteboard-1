function areAnagrams(str1, str2) {
    // Remove whitespace and punctuation, and convert to lowercase
    const cleanStr1 = str1.replace(/[\s,.!?]/g, '').toLowerCase();
    const cleanStr2 = str2.replace(/[\s,.!?]/g, '').toLowerCase();
    
    // Check if the lengths of the cleaned strings are different
    if (cleanStr1.length !== cleanStr2.length) {
        return false;
    }
    
    // Count character frequencies in both strings
    const charCount1 = {};
    const charCount2 = {};

    for (const char of cleanStr1) {
        charCount1[char] = (charCount1[char] || 0) + 1;
    }
    
    for (const char of cleanStr2) {
        charCount2[char] = (charCount2[char] || 0) + 1;
    }

    // Compare character frequencies
    for (const char in charCount1) {
        if (charCount1[char] !== charCount2[char]) {
            return false;
        }
    }

    return true;
}

// Example usage:
const str1 = "Listen";
const str2 = "silent";
console.log(areAnagrams(str1, str2)); // Output: true
