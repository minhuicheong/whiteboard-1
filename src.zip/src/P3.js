function generateFibonacci(n) {
    const sequence = [];
    let a = 0;
    let b = 1;

    for (let i = 0; i < n; i++) {
        sequence.push(a);
        const temp = a;
        a = b;
        b = temp + b;
    }

    return sequence;
}

// Example usage (same as before):
const n = 10; // Number of Fibonacci sequence elements to generate
const fibonacciSequence = generateFibonacci(n);
console.log(fibonacciSequence.join(', '));
