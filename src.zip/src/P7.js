function squareRoot(x) {
    if (x === 0 || x === 1) {
        return x;
    }
    
    let guess = x; // Initial guess
    
    while (true) {
        const nextGuess = 0.5 * (guess + x / guess); // Calculate the next guess
        
        // Check if the difference between consecutive guesses is very small (close enough to the square root)
        if (Math.abs(nextGuess - guess) < 1e-7) {
            return Math.floor(nextGuess); // Return the floor of the square root
        }
        
        guess = nextGuess; // Update the guess for the next iteration
    }
}

// Example usage:
const x = 36; // Perfect square (e.g., 4, 9, 16, 25, 36, ...)
const result = squareRoot(x);
console.log(result); // Output: 6
