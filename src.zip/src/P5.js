function findSymmetricDifference(list1, list2) {
    const symmetricDifference = [];

    // Iterate through list1 and check for unique elements
    for (const element1 of list1) {
        if (!list2.includes(element1) && !symmetricDifference.includes(element1)) {
            symmetricDifference.push(element1);
        }
    }

    // Iterate through list2 and check for unique elements
    for (const element2 of list2) {
        if (!list1.includes(element2) && !symmetricDifference.includes(element2)) {
            symmetricDifference.push(element2);
        }
    }

    return symmetricDifference;
}

// Example usage:
const list1 = [4, 5, 2, 3, 1, 6];
const list2 = [8, 7, 6, 9, 4, 5];

const result = findSymmetricDifference(list1, list2);
console.log(result); // Output: [1, 2, 3, 7, 8, 9]
