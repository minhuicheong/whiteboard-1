function findIntersection(list1, list2) {
    const intersection = [];
    
    for (const element1 of list1) {
        for (const element2 of list2) {
            if (element1 === element2) {
                intersection.push(element1);
                break; // Break out of the inner loop once a match is found
            }
        }
    }
    
    return intersection;
}

// Example usage:
const list1 = [4, 5, 2, 3, 1, 6];
const list2 = [8, 7, 6, 9, 4, 5];

const result = findIntersection(list1, list2);
console.log(result); // Output: [4, 5, 6]
